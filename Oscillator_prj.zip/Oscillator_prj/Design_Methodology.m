%%% Data Plotting
%%% Eindhoven Unversity of Technology
%%% Authors: Dr. Carlos Mendes Jr.

%%%   SYSTEM STARTUP   %%%

% Initialize
clear all; close all; clc;

%%%   VARIABLES   %%%

% General
f = 1e6;
w = 2*pi*f;

% Design Variables
res_s = 0.6*4;
Id = 1e-3;
vout_p = 4;

% Transistor
kp = 20.45e-6;
W_L = 80;
Vth = 1.3;

% VCO
w1 = 0.9*w;
w2 = 1.1*w;
V1 = 0;
V2 = 5;

%%%   CALCULATIONS   %%%

% 1 - Find the tank parallel resistance for a given Vout_p and Id
res_p = (vout_p*pi)/(4*Id);
disp(['Tank parallel resistance: ' num2str(res_p/1e3) ' kOhms']);

% 2 - Equivalent parallel resistance
ind = sqrt((res_p*res_s)/(w^2));
disp(['Required inductor: ' num2str(ind*1e6) ' uH']);

% 3 - Get the transistor biasing (sizing)

  % 3.1 - Minimum condition for oscillation
  gm = 1/res_p; 
  disp(['gm has to be larger than: ' num2str(gm*1e6) ' uS']);
  
  % 3.2 - Calculate the biasing required for the gm found
  Vgs = ((5*gm)/(kp*W_L))+ Vth;
  disp(['Biasing: ' num2str(Vgs) ' V']);
  
% 4 - Required capacitance
cap = 1/(ind*w^2);
disp(['Required total capacitance: ' num2str(cap*1e12) ' pF']);

% 5 - Calculate the required kVCO
kVCO = (w2-w1)/(V2-V1);
disp(['Required kVCO: ' num2str(kVCO/1e3) ' kHz/V']);

% 6 - Calculate required variable capacitor range
cap_max = 1/(ind*w1^2);
cap_min  = 1/(ind*w2^2);
disp(['Minimum cap: ' num2str(cap_min*1e12) ' pF']);
disp(['Maximum cap: ' num2str(cap_max*1e12) ' pF']);
disp(['Required varcap range: +-' num2str((cap_max-cap_min)*1e12) ' pF']);

